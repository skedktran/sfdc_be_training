#Confluence page
https://skedulo.atlassian.net/wiki/spaces/GCS/pages/2110259307/BE+Team+Assets
